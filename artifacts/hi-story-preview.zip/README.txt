雾桥递信 · 已构建网页
解压后在此目录运行 python3 -m http.server 8080 ，打开 http://localhost:8080 。
也可使用任意 HTTP 静态服务器。不要直接 file:// 打开。
没有持久存档；刷新新开局。无网络素材、服务端或数据库。
